SEG salt velocity models for training process.
