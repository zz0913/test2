Synthetic velocity models for training process
