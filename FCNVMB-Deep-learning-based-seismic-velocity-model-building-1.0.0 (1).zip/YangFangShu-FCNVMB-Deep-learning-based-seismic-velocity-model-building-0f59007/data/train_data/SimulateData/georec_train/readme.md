The corresponding synthetic seismic measurement by solving the 2D constant density acoustic wave equation
